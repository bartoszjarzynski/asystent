package com.example.asystent.model

data class SubjectModelCheck(val id: Int, val name: String, val day: String, val hours: String, var isSelected: Boolean)
