package com.example.asystent.model

object Data {

    val days : List<String> = listOf(
        "Poniedziałek",
        "Wtorek",
        "Środa",
        "Czwartek",
        "Piątek"
    )

    val marks = arrayOf(
        "2",
        "3",
        "3.5",
        "4",
        "4.5",
        "5"
    )
}